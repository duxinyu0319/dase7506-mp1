"""Baseline GPT with dropout on residual branches."""

import torch
from torch import nn
from torch.nn import functional as F
from model import GPT


class StudentGPT(GPT):
    def __init__(self, config):
        super().__init__(config)
        probability = float(config.get("dropout", 0.0))
        if not 0 <= probability < 1:
            raise ValueError("dropout must be in [0, 1).")
        self.residual_dropout = nn.Dropout(probability)

    def features(self, ids):
        positions = torch.arange(ids.shape[1], device=ids.device)
        x = self.token(ids) + self.pos(positions)

        for block in self.blocks:
            batch, length, width = x.shape

            q, k, v = (
                block.qkv(block.norm1(x))
                .view(
                    batch, length, 3,
                    block.heads, width // block.heads
                )
                .permute(2, 0, 3, 1, 4)
            )

            attended = F.scaled_dot_product_attention(
                q, k, v, is_causal=True
            )

            attention_output = block.proj(
                attended.transpose(1, 2)
                .reshape(batch, length, width)
            )

            x = x + self.residual_dropout(attention_output)
            x = x + self.residual_dropout(
                block.mlp(block.norm2(x))
            )

        return self.norm(x)


def build_model(config):
    return StudentGPT(config)
