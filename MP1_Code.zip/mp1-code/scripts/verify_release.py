from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
for package in [root, root.parent / "mp1-checkpoints"]:
    manifest = json.loads((package / "SHA256SUMS.json").read_text())
    for name, expected in manifest.items():
        path = package / name
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(f"Hash mismatch: {path}")
    print(f"Verified {len(manifest)} files in {package.name}")
