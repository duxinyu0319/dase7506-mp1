#!/bin/sh
set -eu
# Run from mp1-code. Each run starts from random initialization.
python train.py --implementation model --config configs/baseline.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 1200 --batch-size 32 --eval-every 300 --run-dir runs/reproduced-baseline-s17
python train.py --implementation student --config configs/dropout0.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 3600 --batch-size 32 --eval-every 600 --run-dir runs/reproduced-dropout0-3600-s17
python train.py --implementation student --config configs/dropout0.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 1200 --batch-size 32 --eval-every 300 --run-dir runs/reproduced-dropout0-s17
python train.py --implementation student --config configs/dropout01.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 3600 --batch-size 32 --eval-every 600 --run-dir runs/reproduced-dropout01-3600-s17
python train.py --implementation student --config configs/dropout01.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 1200 --batch-size 32 --eval-every 300 --run-dir runs/reproduced-dropout01-s17
python train.py --implementation model --config configs/baseline.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 100 --batch-size 32 --eval-every 0 --run-dir runs/reproduced-speedcheck-100
python train.py --implementation student --config configs/dropout0.json --device cpu --precision fp32 --threads 4 --seed 42 --steps 3600 --batch-size 32 --eval-every 600 --run-dir runs/reproduced-width128-3600-s42
python train.py --implementation student --config configs/width192.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 3600 --batch-size 32 --eval-every 600 --run-dir runs/reproduced-width192-3600-s17
python train.py --implementation student --config configs/width192.json --device cpu --precision fp32 --threads 4 --seed 42 --steps 3600 --batch-size 32 --eval-every 600 --run-dir runs/reproduced-width192-3600-s42
