# MP1: Width scaling and training duration for a small causal GPT

DASE7506 individual coursework. This package contains the frozen implementation, a report, supplied benchmark data, exact training recipes, and raw experimental evidence. Student identity and public submission links must be supplied by the submitter through the course workflow; no identity has been inferred.

## Result and frozen predictor

- Protocol: `7506-mp1-wt2-v2`; CPU FP32, four PyTorch threads.
- Full-test BPB: **1.7228267184138215**. Lower is better.
- Baseline full-test BPB: 2.1012651958438786.
- Final model: width 192, depth 4, heads 4, context 256, vocabulary 2048, dropout 0; 2,222,208 parameters.
- Seed 42; 3,600 steps x batch 32 x 256 targets = 29,491,200 training targets. All runs start from random initialization; no parent checkpoint.
- Final validation BPB: 1.697728808551342; selected using validation only. The lower validation score selected seed 42 from seeds 17 and 42.
- Frozen at 2026-09-29T14:10:30.339454+00:00 (22:10:30 on 29 September, UTC+8).
- Checkpoint SHA-256: `84cdce4e8b8b99169e5a9b5a1010aad3221865bf1693e154e15314c00d71a0dc`.
- A new architecture is not claimed: the contribution is a measured capacity/training-budget study. Residual dropout was implemented and ablated, but rejected on validation evidence.

## Download layout

Download the code archive and matching checkpoint archive from the submitter's immutable code release and checkpoint link. Extract both into the same parent directory:

```text
mp1-code/          # this directory
mp1-checkpoints/
  checkpoint.pt   # FINAL predictor
  baseline/checkpoint.pt  # original baseline, for timing/reproduction only
```

The baseline checkpoint is optional for final scoring and is not an ensemble member. The checkpoint package is self-contained for weights; executable code, tokenizer and benchmark splits are in the code archive. No training or online retrieval is required to evaluate. No optimizer state is needed.

## Installation

Use Python 3.12. The recorded machine is Apple M5 Max (18 CPU cores), 36 GB memory, macOS 26.4, Python 3.12.10; all reported training and scoring used CPU FP32 with four threads. This is a same-machine reproduction, not a claim of cross-platform testing.

```bash
cd mp1-code
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip check
python -m unittest discover -s tests -v
```

On Linux/Windows CPU, install `torch==2.7.1` from `https://download.pytorch.org/whl/cpu` first, then install `requirements.txt`. On Windows activate with `.venv\Scripts\Activate.ps1`. Platform timings must be measured locally. CUDA and MPS are not needed.

For the Python.org macOS installer, run `/Applications/Python 3.12/Install Certificates.command` if HTTPS root certificates were not configured. On the recorded machine, explicitly setting `PIP_CERT=/etc/ssl/cert.pem` resolved the install certificate problem. Do not disable HTTPS verification.

## Evaluate without retraining

From `mp1-code`, after activating the environment:

```bash
python scripts/verify_release.py
python evaluate.py --checkpoint ../mp1-checkpoints/checkpoint.pt --device cpu --precision fp32 --threads 4 --split test --output reproduced/final-test.json
```

The official evaluator is unchanged. Expected targets: 428405; raw UTF-8 bytes: 1292013; BPB: 1.7228267184138215. Small floating-point differences can occur across hardware/software builds. The evaluator also writes per-window `.npy` losses. Evaluation operates offline once dependencies and both archives have been obtained.

Reproduce the original baseline without training:

```bash
python evaluate.py --checkpoint ../mp1-checkpoints/baseline/checkpoint.pt --device cpu --precision fp32 --threads 4 --split test --output reproduced/baseline-test.json
```

## Train from scratch

Final recipe (new output directory required):

```bash
python train.py --implementation student --config configs/width192.json --device cpu --precision fp32 --threads 4 --seed 42 --steps 3600 --batch-size 32 --eval-every 600 --run-dir runs/reproduced-width192-3600-s42
```

Original baseline:

```bash
python train.py --implementation model --config configs/baseline.json --device cpu --precision fp32 --threads 4 --seed 17 --steps 1200 --batch-size 32 --eval-every 300 --run-dir runs/reproduced-baseline-s17
```

`evidence/training_commands.json` gives all nine exact run recipes; `sh scripts/reproduce_all_training.sh` runs them sequentially. This is optional and incurs all training costs. Each run starts fresh. Validation is used for development; do not tune a frozen model on test results. The supplied trainer saves only the final checkpoint, not intermediate validation-best checkpoints. Training step count also changes the cosine learning-rate schedule.

## Experimental controls

Width 128 versus 192 at 3,600 steps uses the same 29,491,200 processed targets, paired seeds 17 and 42, batch size, optimizer, depth and context. This pair also ablates the selected capacity increase. It is not equal-FLOP or equal-wall-time training. Increasing width with four heads also increases head dimension (32 to 48) and MLP width (512 to 768); the comparison tests these coupled consequences of model width.

Dropout 0 versus 0.1 is compared at 1,200 and 3,600 steps with seed 17. It worsened validation BPB at both budgets. The 18.01% final test reduction combines longer training and greater width; it must not be attributed entirely to width. The matched-width comparison yields a 5.14% reduction in mean validation BPB across two seeds.

## Resource measurements and cost disclosure

Original full-test measurements: baseline scoring 4.144501 s; final scoring 5.094313 s; ratio 1.229174; maximum resident set size 2272952320 bytes (2.116852 GiB). The JSON `seconds` measures scoring, not installation/loading. RAM is whole-process maximum RSS from macOS `/usr/bin/time -l`; macOS reports bytes. GPU fields equal to zero are not CPU RAM measurements. See raw files in `evidence/original` and packaged-code verification in `evidence/reproduction`.

```bash
mkdir -p reproduced
/usr/bin/time -l python evaluate.py --checkpoint ../mp1-checkpoints/checkpoint.pt --device cpu --precision fp32 --threads 4 --split test --output reproduced/final-resource-test.json 2> reproduced/final-resource-test.txt
```

Run the equivalent command for `../mp1-checkpoints/baseline/checkpoint.pt` on the same machine, with the same precision, threads and split. Limits: <=5x scoring time, <=4 GiB peak RAM, <=64 MiB uncompressed inference assets. `evidence/asset_inventory.json` lists final predictor assets and a conservative total including executable source and tokenizer. Optional baseline weights and experimental logs are not used by the final predictor; the final predictor is not a mixture.

Nine recorded completed runs processed 177,766,400 targets in 3619.844061 training seconds (60.331 min). Their total training-process time, including preparation/validation/saving, is 3844.059065 s. Original standalone scoring seconds total 17.354724 s; this is not full process time. Packaging verification is recorded separately. Search costs include smoke, duplicate control and failed dropout experiments. Deleted/interrupted attempts, installation, human work and electricity costs cannot be recovered from these logs and are not included. The submitter must disclose any additional unrecorded runs. No course GPU or external pretrained checkpoint was used in the documented workflow.

## Evidence and provenance

- `report.pdf` and editable `report.md`: six-page report including figures and references.
- `evidence/runs/*/metrics.json`: every completed-run record.
- `evidence/original`: supplied CSV/XLSX summaries, scoring JSON, resource text and per-window losses.
- `evidence/freeze_record.json`: original freeze record.
- `evidence/source_audit.json`: hash, workbook/CSV and per-window checks.
- `evidence/reproduction`: packaged-code tests and full-test checks, using the existing exact-version Python environment.
- `SHA256SUMS.json` plus `scripts/verify_release.py`: content integrity check.
- `reference/STARTER_PACKAGE_MANIFEST.json`: original release manifest, not the manifest for this modified submission. The supplied GUIDE and README do not match that original manifest; fixed code/data do. The received documents are preserved unchanged for provenance.

## AI assistance and reused work

Substantive OpenAI Codex assistance was used to interpret the assignment, troubleshoot the Python environment, propose experiments, generate the residual-dropout implementation and run commands, interpret results, and draft/package the report and reproduction materials. The student executed the recorded training experiments following this assistance. Packaging checks were subsequently run by Codex. The student remains responsible for reviewing and understanding the code, analysis and submission; this README does not assert that such review has already occurred.

The GPT, trainer, optimizer recipe, data/tokenizer, fixed evaluator and tests are reused from the DASE7506 starter. The final model retains the baseline architecture family with changed width and training duration. `student.py` contains the assisted residual-dropout extension; its probability is zero in the selected checkpoint. No external training text, pretrained weights, retrieval database, cached answers or cross-window state was added.

## Dataset attribution

WikiText-2 was introduced by Stephen Merity, Caiming Xiong, James Bradbury and Richard Socher in *Pointer Sentinel Mixture Models*: https://arxiv.org/abs/1609.07843 . Text is by Wikipedia contributors. The supplied source identifies CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/) and the GNU Free Documentation License (https://www.gnu.org/licenses/fdl-1.3.html). Retain these notices when redistributing. Dataset source: https://huggingface.co/datasets/Salesforce/wikitext ; revision `b08601e04326c79dfdd32d625aee71d232d685c3`. These notices do not assign a new license to classroom code. No additional filtering or tokenizer fitting was performed for this submission.
